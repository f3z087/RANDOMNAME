package edu.metrostate.ics372.RANDOMNAME.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class represents a warehouse object
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class Warehouse {

    private String warehouseID;
    private String name;
    private boolean freightReceipt;
    private List<Shipment> listOfShipments;

    /**
     * Default no argument constructor.
     */
    public Warehouse() {
        listOfShipments = new ArrayList<>();
    }


    /**
     * Constructor to create a new warehouse object with a name and warehouseID. Initializes the warehouses list of
     * shipments and enables freight receipt.
     *
     * @param warehouseID
     * @param name
     */
    public Warehouse(String warehouseID, String name) {

        this.warehouseID = warehouseID;
        this.name = name;
        //initialize list of shipments
        listOfShipments = new ArrayList<Shipment>();
        //enable freight receipt
        enableFreightReceipt();
    }

    /**
     * Get warehouse ID of the warehouse.
     *
     * @return warehouseID
     */
    public String getWarehouseID() {
        return warehouseID;
    }

    /**
     * Gets the name of the warehouse object.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the list of shipments as an arraylist for the warehouse
     *
     * @return list of shipments for the warehouse
     */
    public List<Shipment> getListOfShipments() {
        return listOfShipments;
    }

    /**
     * Sets the name of the warehouse object. This should be used if you are changing the name of a warehouse.
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the freight receipt value to true, indicating that the warehouse can receive shipments.
     */
    public void enableFreightReceipt() {
        this.freightReceipt = true;
    }

    /**
     * Returns true if the warehouse has freight receipt enabled. Returns false if the warehouse has freight receipt disabled.
     *
     * @return freightReceipt
     */
    public boolean isFreightReceipt() {
        return this.freightReceipt;
    }

    /**
     * Sets freight receipt value to false, indicating that the warehouse is not able to receive anymore shipments.
     */
    public void disableFreightReceipt() {
        this.freightReceipt = false;
    }

    /**
     * Adds incoming shipment into listOfShipments
     *
     * @param shipment
     */
    public void addIncomingShipment(Shipment shipment) {
        //if freight receipt is allowed then add the shipment
        if (isFreightReceipt()) {
            //add shipment to list of shipments
            listOfShipments.add(shipment);
        } else {
            //should probably handle this differently
            System.out.println("Freight Receipt is not enabled for this warehouse" + shipment.getWarehouseID() + "/n"
                    + "Shipment was not added" + shipment.getShipmentID());
        }

    }


}
