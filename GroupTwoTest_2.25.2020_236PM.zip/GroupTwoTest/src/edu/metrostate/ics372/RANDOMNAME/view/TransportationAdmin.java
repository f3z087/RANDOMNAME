package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

/**
 * Main form class.
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class TransportationAdmin {
    private JButton exitButton;
    private JButton addShipmentFromFileButton;
    private JButton addShipmentManuallyButton;
    private JButton viewShipmentsForWarehouseButton;
    private JButton viewWarehousesButton;
    private JButton enableDisableFreightReceiptButton;
    private JButton addWarehouseButton;
    private JPanel transportAdminForm;

    /**
     * No argument constructor, enables the listeners for the buttons.
     */
    public TransportationAdmin() {
        addShipmentFromFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               //open the AddShipmentFromFile form
                AddShipmentFromFile addShipmentFromFile = new AddShipmentFromFile();
                addShipmentFromFile.setVisible(true);

            }
        });

        addShipmentManuallyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddShipmentManually addShipmentManually = new AddShipmentManually();
                addShipmentManually.setVisible(true);

            }
        });

        viewShipmentsForWarehouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ViewShipmentsForWarehouse viewShipmentsForWarehouse = new ViewShipmentsForWarehouse();
                viewShipmentsForWarehouse.setVisible(true);
            }
        });
        viewWarehousesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ViewWarehouses viewWarehouses = new ViewWarehouses();
                viewWarehouses.setVisible(true);
            }
        });
        addWarehouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddWarehouse addWarehouse = new AddWarehouse();
                addWarehouse.setVisible(true);
            }
        });

        enableDisableFreightReceiptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EnableDisableFreightReceipt freightReceipt = new EnableDisableFreightReceipt();
                freightReceipt.setVisible(true);

            }
        });
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //exit the program
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("TransportationAdmin");
        frame.setContentPane(new TransportationAdmin().transportAdminForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
