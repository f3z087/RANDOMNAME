package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.Shipment;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Controller class for the AddShipmentFromFile class.
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class AddShipmentManually extends JPanel {
    private JTextField warehouseIDText;
    private JComboBox shipMethodCombo = new JComboBox();
    private JTextField shipIDText;
    private JTextField weightText;
    private JButton addShipmentButton;
    private JPanel addShipManForm;
    private JTextField receiptDateText;

    /**
     * No argument constructor, initializes the button listeners and defines the actions.
     */
    public AddShipmentManually() {
        addShipmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get warehouseIDText field
                String warehouseID = warehouseIDText.getText();
                //get choice from shipMethodCombo and change into an enum ShipmentMethod

                //get shipIDText
                String shipmentID = shipIDText.getText();
                //get weightText and change into a Long value
                String weight = weightText.getText();

                //get receipt date and change into Date format
                //create new shipment Shipment shipment = new Shipment();
                //add to warehouse listOfShipments - get warehouse object from whRepo then add shipment to list

            }
        });
        shipMethodCombo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                //used to capture which choice is selected in the combo box
            }
        });
    }
    public ArrayList<Shipment.ShipmentMethod> getShipmentMethods() {
        return new ArrayList<Shipment.ShipmentMethod>(Arrays.asList(Shipment.ShipmentMethod.values()));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("AddShipmentManually");
        frame.setContentPane(new AddShipmentManually().addShipManForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
