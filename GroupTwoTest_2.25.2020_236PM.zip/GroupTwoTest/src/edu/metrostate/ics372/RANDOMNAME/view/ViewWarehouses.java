package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Class that controls the View Warehouses form functionality
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class ViewWarehouses extends JPanel {
    private JPanel viewWarehouse;
    private JList listOfWarehousesList;
    private JButton viewWarehouses;

    /**
     * No argument constructor with action listeners for buttons
     */
    public ViewWarehouses() {
        viewWarehouses.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //populate the text area with the warehouse repository map or json printout
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ViewWarehouses");
        frame.setContentPane(new ViewWarehouses().viewWarehouse);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
