package edu.metrostate.ics372_assignment3.model;

public class ChooseFile {
}
