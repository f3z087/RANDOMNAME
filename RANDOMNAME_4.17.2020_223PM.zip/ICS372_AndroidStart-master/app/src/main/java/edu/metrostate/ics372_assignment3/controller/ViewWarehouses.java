package edu.metrostate.ics372_assignment3.controller;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.Warehouse;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

public class ViewWarehouses extends AppCompatActivity {

    private ListView viewWarehousesList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_warehouses);

       viewWarehousesList = findViewById(R.id.warehousesListView);
        ArrayAdapter<Warehouse> adapter = new ArrayAdapter<Warehouse>
                (this, android.R.layout.simple_list_item_1,
                        new ArrayList<Warehouse>(WarehouseRepository.getInstance().getWhRepo().values()));
        viewWarehousesList.setAdapter(adapter);


    }
}
