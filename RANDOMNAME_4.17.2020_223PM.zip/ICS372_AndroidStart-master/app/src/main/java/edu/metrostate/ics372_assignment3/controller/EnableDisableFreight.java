package edu.metrostate.ics372_assignment3.controller;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.Warehouse;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

public class EnableDisableFreight extends AppCompatActivity {
    private Button enableButton;
    private Button disableButton;
    private Spinner warehouseIDSpinner;
    private Dialog errWhID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enable_disable_freight);

        warehouseIDSpinner = (Spinner) findViewById(R.id.shipManWhIDSpinner);
        enableButton = (Button) findViewById(R.id.enableButton);
        disableButton = (Button) findViewById(R.id.disableButton);

        //populate spinner with warehouse ID's
        ArrayAdapter<String> whSpinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item,
                new ArrayList<String>(WarehouseRepository.getInstance().getWhRepo().keySet()));
        //specify layout to use when list of choices appears
        whSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //apply the adapter to the spinner
        warehouseIDSpinner.setAdapter(whSpinnerAdapter);

        //capture enableButton btn clicks
        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String warehouseIDStr = warehouseIDSpinner.getSelectedItem().toString();
                if(warehouseIDStr.isEmpty()){
                    //display message that the warehouse needs to be typed in.
                    errWhID = new AlertDialog.Builder(EnableDisableFreight.this)
                            .setMessage("Please select a warehosue").show();
                }
                Warehouse warehouseObj = WarehouseRepository.getInstance().getWarehouse(warehouseIDStr);
                warehouseObj.enableFreightReceipt();
                //display message freight receipt enabled
                if(warehouseObj.isFreightReceipt()){
                    Toast.makeText(EnableDisableFreight.this,
                            "Freight receipt enabled", Toast.LENGTH_SHORT).show();
                }

            }
        });
        //capture disableButton btn clicks
        disableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String warehouseIDStr = warehouseIDSpinner.getSelectedItem().toString();
                if(warehouseIDStr.isEmpty()){
                    //display message that the warehouse needs to be typed in
                }
                Warehouse warehouseObj = WarehouseRepository.getInstance().getWarehouse(warehouseIDStr);
                warehouseObj.disableFreightReceipt();
                //display message freight receipt disabled
                Toast.makeText(EnableDisableFreight.this,
                        "Freight receipt disabled.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
