package edu.metrostate.ics372_assignment3.controller;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import edu.metrostate.ics372_assignment3.R;
import edu.metrostate.ics372_assignment3.model.ShipShipments;
import edu.metrostate.ics372_assignment3.model.Shipment;
import edu.metrostate.ics372_assignment3.model.Warehouse;
import edu.metrostate.ics372_assignment3.model.WarehouseRepository;

public class ShipShipment extends AppCompatActivity {
    private Spinner warehouseShipFromSpinner;
    private Spinner toShipSpinner;
    private Spinner warehouseShipToSpinner;
    private Button shipButton;
    private Dialog selectWarehouse;
    private Dialog shipmentErr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ship_shipment);

        //populate warehouseShipFromSpinner
        warehouseShipFromSpinner = findViewById(R.id.warehouseShipFromSpinner);
        final ArrayAdapter<String> warehouseAdapter = new ArrayAdapter<String>
                (ShipShipment.this, android.R.layout.simple_spinner_item,
                        new ArrayList<String>(WarehouseRepository.getInstance().getWhRepo().keySet()));
        warehouseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        warehouseShipFromSpinner.setAdapter(warehouseAdapter);

        ///on selection populate toShipSpinner with list of shipments at the warehouse
        warehouseShipFromSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String warehouseFrom = warehouseShipFromSpinner.getSelectedItem().toString();
                if(warehouseFrom != null){
                    toShipSpinner.findViewById(R.id.shipmentIDSpinner);
                    ArrayAdapter<String> shipmentIDAdapter = new ArrayAdapter<String>
                            (ShipShipment.this, android.R.layout.simple_spinner_item,
                                    WarehouseRepository.getInstance().getWarehouse(warehouseFrom).getListOfShipID());
                    shipmentIDAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    toShipSpinner.setAdapter(shipmentIDAdapter);

                    //when shipment to ship is selected populate warehouseShipToSpinner
                    toShipSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            warehouseShipToSpinner = findViewById(R.id.warehouseShipToSpinner);
                            warehouseShipToSpinner.setAdapter(warehouseAdapter);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                }else{
                    //dialog saying please select warehouse to ship from
                    selectWarehouse= new AlertDialog.Builder(ShipShipment.this)
                            .setMessage("Please select a warehouse to ship from.").show();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //dialog please select something
                selectWarehouse= new AlertDialog.Builder(ShipShipment.this)
                        .setMessage("Please select a warehouse to ship from.").show();
            }
        });



        //locate ship button in activity_ship_shipment
        shipButton = (Button) findViewById(R.id.shipButton);
        //capture shipButton clicks
        shipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ship shipment selected in toShipSpinner to warehouse selected in warehouseShipToSpinner
                String warehouseFrom = warehouseShipFromSpinner.getSelectedItem().toString();
                String shipmentIDToShip = toShipSpinner.getSelectedItem().toString();
                String warehouseTo = warehouseShipToSpinner.getSelectedItem().toString();

                Shipment toShip = WarehouseRepository.getInstance().getWarehouse(warehouseFrom)
                                .getShipment(shipmentIDToShip);
                Warehouse warehouse = WarehouseRepository.getInstance().getWarehouse(warehouseTo);
                if(toShip != null){
                    ShipShipments shipShipment = new ShipShipments(toShip, warehouse);
                    shipShipment.ship();
                }else{
                    //dialog shipment does not exist at this warehouse
                    shipmentErr= new AlertDialog.Builder(ShipShipment.this)
                            .setMessage("Shipment does not exist at this warehouse.").show();
                }



            }
        });


    }


}
