package edu.metrostate.ics372_assignment3.controller;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import edu.metrostate.ics372_assignment3.R;

public class AddShipFromFile extends AppCompatActivity {
    private Button chooseFileButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get the view from activity_add_shipment_from_file
        setContentView(R.layout.activity_add_shipment_from_file);

        chooseFileButton = (Button) findViewById(R.id.chooseFileButton);

        chooseFileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //choose file using the choose file class
                //display err if file not valid
                //if file extension is .xml call importShipmentsXML class
                //if file extension is .json call importShipmentsJSON class
                //display dialog that this has completed successfully

            }
        });

    }
}
