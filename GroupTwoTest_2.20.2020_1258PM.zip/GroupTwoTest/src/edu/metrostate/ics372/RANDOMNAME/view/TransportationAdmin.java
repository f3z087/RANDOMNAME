package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;

public class TransportationAdmin {
    private JButton exitButton;
    private JButton addShipmentFromFileButton;
    private JButton addShipmentManuallyButton;
    private JButton viewShipmentsForWarehouseButton;
    private JButton viewWarehousesButton;
    private JButton enableDisableFreightReceiptButton;
    private JButton addWarehouseButton;
    private JPanel transportAdminForm;

    public static void main(String[] args) {
        JFrame frame = new JFrame("TransportationAdmin");
        frame.setContentPane(new TransportationAdmin().transportAdminForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
