package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddWarehouse {

    private JTextField warehouseIDText;
    private JTextField warehouseNameText;
    private JButton addWarehouseButton;
    private JPanel addWarehouseForm;

    public AddWarehouse() {
        addWarehouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get the text from the warehouseIDText field
                //get the text from the warehouseNameText field
                //create new warehouse Warehouse warehouse = new Warehouse(warehouseIDText, warehouseNameText);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("AddWarehouse");
        frame.setContentPane(new AddWarehouse().addWarehouseForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
