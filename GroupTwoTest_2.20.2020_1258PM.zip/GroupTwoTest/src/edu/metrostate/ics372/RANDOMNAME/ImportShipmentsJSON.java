package edu.metrostate.ics372.RANDOMNAME;

/**
 * Import shipments from a JSON file and put them into the appropriate warehouse listOfShipments
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class ImportShipmentsJSON {
}
