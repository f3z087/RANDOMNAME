package edu.metrostate.ics372.RANDOMNAME.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Singleton class to manage the different warehouse objects.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class WarehouseRepository {
    private Map<String, Warehouse> whRepo = new HashMap<>();
    private static WarehouseRepository singleton;

    private WarehouseRepository() {

    }

    /**
     * Get an instance of the warehouse repository. Will create a new instance if one has not already been created.
     *
     * @return warehouse repository class instance
     */
    public static WarehouseRepository getInstance() {
        if (singleton == null) {
            singleton = new WarehouseRepository();
        }
        return singleton;
    }
}
