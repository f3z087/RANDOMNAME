package edu.metrostate.ics372.RANDOMNAME.model;

import org.json.simple.JSONArray;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Prints the list of shipments for a warehouse.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class PrintShipments {

    public PrintShipments(){

    }

    /**
     * NEEDS TO BE REWRITTEN TO WORK AS A CLASS - NEED TO FIGURE OUT WHERE TO PUT THE PRINTED FILE
     * Prints the listOfShipments to a json file.
     */
    public void printReceivedShipments(String filePath) {

        JSONArray warehouseContents = new JSONArray();
        // add shipments to the list
        warehouseContents.addAll(this.listOfShipments);

        // write json file
        try (FileWriter file = new FileWriter(filePath)) {
            file.write(warehouseContents.toJSONString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
