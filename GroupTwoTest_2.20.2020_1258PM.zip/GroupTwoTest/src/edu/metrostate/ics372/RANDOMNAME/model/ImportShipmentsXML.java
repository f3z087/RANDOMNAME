package edu.metrostate.ics372.RANDOMNAME.model;

/**
 * Fulfill New Feature #3 on Group 2 Assignment sheet. This class should take the XML shipments and convert them to
 * shipment objects. Similar to what we did when we import shipments from a json file.
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class ImportShipmentsXML {
}
