package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EnableDisableFreightReceipt {
    private JTextField warehouseIDText;
    private JButton enableButton;
    private JButton disableButton;
    private JPanel enDisFreightRecForm;

    public EnableDisableFreightReceipt() {
        enableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when the button is pressed get the text from the warehouse id field
                //get the warehouse object from the warehouse repository whRepo
                //perform the enableFreightReceipt method on the warehouse object
            }
        });
        disableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when the button is pressed get the text from the warehouse id field
                //get the warehouse object from the warehouse repository whRepo
                //preform the disableFreightReceipt method on teh warehouse object

            }
        });
    }

    /**
     * Could create a method to call for these actions since they are repeated
     *   //when the button is pressed get the text from the warehouse id field
     *   //get the warehouse object from the warehouse repository whRepo
     *
     */

    public static void main(String[] args) {
        JFrame frame = new JFrame("EnableDisableFreightReceipt");
        frame.setContentPane(new EnableDisableFreightReceipt().enDisFreightRecForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
