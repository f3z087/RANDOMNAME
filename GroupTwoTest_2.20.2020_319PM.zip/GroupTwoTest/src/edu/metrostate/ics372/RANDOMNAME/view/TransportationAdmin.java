package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransportationAdmin {
    private JButton exitButton;
    private JButton addShipmentFromFileButton;
    private JButton addShipmentManuallyButton;
    private JButton viewShipmentsForWarehouseButton;
    private JButton viewWarehousesButton;
    private JButton enableDisableFreightReceiptButton;
    private JButton addWarehouseButton;
    private JPanel transportAdminForm;

    public TransportationAdmin() {
        addShipmentFromFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               //open the AddShipmentFromFile form
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("TransportationAdmin");
        frame.setContentPane(new TransportationAdmin().transportAdminForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
