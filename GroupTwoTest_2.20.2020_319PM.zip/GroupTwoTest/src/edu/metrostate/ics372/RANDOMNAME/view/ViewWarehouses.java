package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;

public class ViewWarehouses {
    private JPanel viewWarehouse;
    private JList listOfWarehousesList;

    public static void main(String[] args) {
        JFrame frame = new JFrame("ViewWarehouses");
        frame.setContentPane(new ViewWarehouses().viewWarehouse);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
