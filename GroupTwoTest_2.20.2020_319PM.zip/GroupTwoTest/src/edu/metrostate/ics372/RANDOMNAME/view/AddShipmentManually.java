package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddShipmentManually {
    private JTextField warehouseIDText;
    private JComboBox shipMethodCombo;
    private JTextField shipIDText;
    private JTextField weightText;
    private JButton addShipmentButton;
    private JPanel addShipManForm;
    private JTextField receiptDateText;

    public AddShipmentManually() {
        addShipmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get warehouseIDText field
                //get choice from shipMethodCombo and change into an enum ShipmentMethod
                //get shipIDText
                //get weightText and change into a Long value
                //get receipt date and change into Date format
                //create new shipment Shipment shipment = new Shipment();
                //add to warehouse listOfShipments - get warehouse object from whRepo then add shipment to list

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("AddShipmentManually");
        frame.setContentPane(new AddShipmentManually().addShipManForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
