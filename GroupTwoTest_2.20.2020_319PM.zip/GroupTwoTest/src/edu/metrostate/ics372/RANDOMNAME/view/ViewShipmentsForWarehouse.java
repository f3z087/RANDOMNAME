package edu.metrostate.ics372.RANDOMNAME.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewShipmentsForWarehouse {
    private JButton printToFileButton;
    private JButton viewButton;
    private JPanel viewShipForWareForm;
    private JTextField warehouseIDText;
    private JTextArea listOfShipTextArea;


    public ViewShipmentsForWarehouse() {
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get text from warehouseIDText field
                //get warehouse object from whRepo with indicated warehouseID
                //get the list of shipments of this warehouseID
                //display the list of shipments in the listOfShipTextArea

            }
        });
        printToFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //use the text in the warehouseIDText field
                //get the warehouse object from whRepo with indicated warehouseID
                //get the list of shipments for the warehouse and print the list to a file using PrintShipments class

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ViewShipmentsForWarehouse");
        frame.setContentPane(new ViewShipmentsForWarehouse().viewShipForWareForm);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
