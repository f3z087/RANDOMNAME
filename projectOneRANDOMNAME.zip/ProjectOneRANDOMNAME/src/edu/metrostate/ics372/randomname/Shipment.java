package edu.metrostate.ics372.randomname;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Shipment object class represents one shipment.
 * 
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 *
 */
public class Shipment {

	private String shipmentID;
	private String warehouseID;
	private ShipmentMethod shipmentMethod;
	private Number weight;
	private long receiptDate;

	/**
	 * constructor for shipment object
	 * 
	 * @param shipmentID
	 * @param warehouseID
	 * @param shipmentMethod
	 * @param weight
	 * @param receiptDate
	 */
	public Shipment(String shipmentID, String warehouseID, ShipmentMethod shipmentMethod, Number weight,
			long receiptDate) {
		this.shipmentID = shipmentID;
		this.warehouseID = warehouseID;
		this.shipmentMethod = shipmentMethod;
		this.weight = weight;
		this.receiptDate = receiptDate;
	}

	/**
	 * support 4 different types of shipping methods
	 */
	public enum ShipmentMethod {
		air, truck, ship, rail;
	}

	/**
	 * Gets the shipment ID of the shipment object.
	 * 
	 * @return shipment ID
	 */
	public String getShipmentID() {
		return this.shipmentID;
	}

	/**
	 * Gets the receiving warehouse ID of the shipment.
	 * 
	 * @return
	 */
	public String getWarehouseID() {
		return this.warehouseID;
	}

	/**
	 * Sets the receiving warehouse ID for the shipment
	 * 
	 * @param warehouseID
	 */
	public void setWarehouseID(String warehouseID) {
		this.warehouseID = warehouseID;
	}

	/**
	 * Gets the shipment method for a shipment.
	 * 
	 * @return shipment method
	 */
	public ShipmentMethod getShipmentMethod() {
		return this.shipmentMethod;
	}

	/**
	 * Sets the shipment method of the shipment.
	 * 
	 * @param shipmentMethod
	 */
	public void setShipmentMethod(ShipmentMethod shipmentMethod) {
		this.shipmentMethod = shipmentMethod;
	}

	/**
	 * Gets the weight of the shipment.
	 * 
	 * @return weight.
	 */
	public Number getWeight() {
		return this.weight;
	}

	/**
	 * Gets the date in milliseconds.
	 * 
	 * @return receipt date in milliseconds
	 */
	public long getDateInMS() {
		return this.receiptDate;
	}

	/**
	 * Gets the receipt date of the shipment.
	 * 
	 * @return receipt date
	 */
	public Date getDate() {
		Timestamp ts = new Timestamp(this.receiptDate);
		Date date = ts;
		return date;
	}

	/**
	 * displays all contents in shipment
	 */
	@Override
	public String toString() {
		String output = "";
		output += "Shipment ID: " + this.getShipmentID() + "\nWarehouse ID: " + this.getWarehouseID()
				+ "\nShipment method: " + this.getShipmentMethod().name() + "\nWeight: " + this.getWeight() + "\nDate: "
				+ this.getDate() + "\n";
		return output;
	}

}
