package edu.metrostate.ics372.randomname;

import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.JFileChooser;

/**
 * Choose file using jfilechooser. Saving directory of file to write to.
 * 
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 *
 */
public class ChooseFile {

	private JFileChooser fileChooser = new JFileChooser();
	private File inputDirectory;
	private java.io.File inputFile;

	/**
	 * choose file save directory of file
	 * 
	 * @throws FileNotFoundException
	 */
	public void openFile() throws FileNotFoundException {

		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			inputFile = fileChooser.getSelectedFile();
			inputDirectory = fileChooser.getCurrentDirectory();
		} else {
			System.out.println("No file selected");
		}
	}

	/**
	 * getter methods
	 * 
	 * @return their respective values
	 */
	public File getFile() {
		return this.inputFile;
	}

	/**
	 * Get input directory of file.
	 * 
	 * @return directory as a string
	 */
	public String getDirectory() {
		return this.inputDirectory.getPath();
	}

}
