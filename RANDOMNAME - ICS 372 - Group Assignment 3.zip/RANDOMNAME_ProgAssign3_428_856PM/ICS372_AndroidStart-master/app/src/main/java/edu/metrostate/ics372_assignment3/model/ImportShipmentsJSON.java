package edu.metrostate.ics372_assignment3.model;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Import shipments from a JSON file and put them into the appropriate warehouse listOfShipments
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class ImportShipmentsJSON {
    /**
     * This reads in shipments in, creates shipment objects and then adds them a list and then loops through the list
     * and adds them to the correct warehouse
     */
    public static void readInShipments(String filePath) {
        List<Shipment> shipments = new ArrayList<>();

        // https://www.javaguides.net/2019/07/jsonsimple-tutorial-read-and-write-json-in-java.html

        // JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader(filePath)) {

            try {
                // read JSON file
                Object obj = jsonParser.parse(reader);

                // convert object to JSONObject
                JSONObject jsonObject = (JSONObject) obj;

                JSONArray arrayOfShipments = (JSONArray) jsonObject.get("warehouse_contents");

                // check size if more than 0, there is objects inside the array
                //System.out.println(arrayOfShipments.size());

                // create shipment objects
                Iterator i = arrayOfShipments.iterator();
                while (i.hasNext()) {
                    // reading object in array from json file
                    JSONObject innerObject = (JSONObject) i.next();

                    // getting attributes of the object
                    String warehouseId = innerObject.get("warehouse_id").toString();
                    if (warehouseId.isEmpty() || warehouseId == null) {
                        warehouseId = "";
                    }
                    String shipmentMethod = innerObject.get("shipment_method").toString();
                    if (shipmentMethod.isEmpty() || shipmentMethod == null) {
                        shipmentMethod = "";
                    }
                    String shipmentId = (String) innerObject.get("shipment_id").toString();
                    if (shipmentId.isEmpty() || shipmentId == null) {
                        shipmentId = "";
                    }
                    Object tempWeight = innerObject.get("weight");
                    if (tempWeight == null) {
                        tempWeight = 0.00;
                    }
                    Long tempReceiptDate = (Long) innerObject.get("receipt_date");
                    if (tempReceiptDate == null) {

                        tempReceiptDate = System.currentTimeMillis();
                    }

                    // convert receipt date from long to Date
                    Date receiptDate = new Date(tempReceiptDate);

                    // convert weight to Double
                    Double weight = 0.00;
                    if (tempWeight instanceof Double) {
                        weight = (Double) tempWeight;
                    } else if (tempWeight instanceof Long) {
                        weight = ((Long) tempWeight).doubleValue();
                    }

                    // create a new shipment object
                    Shipment shipment = new Shipment(warehouseId, shipmentMethod, shipmentId, weight, receiptDate);


                    // use this as a check to make sure it is a valid shipment
                    if (shipment.getReceiptDate() != null) {
                        // add shipment to List
                        shipments.add(shipment);
                    }


                }

            } catch (ParseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println("File was not found.");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // can make method for this as well where we pass in a list or can add it to the
        // read in shipments method
        for (Shipment shipment : shipments) {

            // get the warehouse if it exists
            if (WarehouseRepository.getInstance().warehouseExists(shipment.getWarehouseID())) {
                Warehouse warehouse = WarehouseRepository.getInstance().getWarehouse(shipment.getWarehouseID());
                warehouse.addIncomingShipment(shipment);
            } else {

                WarehouseRepository.getInstance().addWarehouse(shipment.getWarehouseID(), "");
                Warehouse warehouse = WarehouseRepository.getInstance().getWarehouse(shipment.getWarehouseID());
                warehouse.addIncomingShipment(shipment);

            }

        }

    }
}