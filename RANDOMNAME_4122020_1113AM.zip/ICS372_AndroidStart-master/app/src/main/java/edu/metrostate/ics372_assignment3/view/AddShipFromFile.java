package edu.metrostate.ics372_assignment3.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import edu.metrostate.ics372_assignment3.R;

public class AddShipFromFile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get the view from activity_add_shipment_from_file
        setContentView(R.layout.activity_add_shipment_from_file);
    }
}
