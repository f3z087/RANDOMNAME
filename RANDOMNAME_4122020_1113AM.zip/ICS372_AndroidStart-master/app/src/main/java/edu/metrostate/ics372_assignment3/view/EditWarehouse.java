package edu.metrostate.ics372_assignment3.view;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import edu.metrostate.ics372_assignment3.R;

public class EditWarehouse extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_warehouse);
    }
}
