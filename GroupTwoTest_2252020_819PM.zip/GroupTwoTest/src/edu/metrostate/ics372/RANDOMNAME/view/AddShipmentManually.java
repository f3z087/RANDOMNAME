package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.Shipment;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

/**
 * Controller class for the AddShipmentFromFile class.
 *
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class AddShipmentManually extends JPanel {
    private JTextField warehouseIDText;
    private JComboBox shipMethodCombo;
    private JTextField shipIDText;
    private JTextField weightText;
    private JButton addShipmentButton;
    private JPanel addShipManForm;
    private JTextField receiptDateText;

    /**
     * No argument constructor, initializes the button listeners and defines the actions.
     */
    public AddShipmentManually() {
        JFrame frame = new JFrame("AddShipmentManually");
        frame.setContentPane(addShipManForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        //populate combo box with shipment methods
        for(Shipment.ShipmentMethod shipmentMethod : getShipmentMethods()){
            shipMethodCombo.addItem(shipmentMethod.name());
        }

        addShipmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get warehouseIDText field
                String warehouseID = warehouseIDText.getText();
                //get shipIDText
                String shipmentID = shipIDText.getText();
                //get weightText and change into a Long value
                String weightStr = weightText.getText();

                //get receipt date and change into Date format
                LocalDate receiptDate;
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                String receiptDateStr = receiptDateText.getText();
                //if it is a valid date then set the receipt date if not display message
                if(isValidDate(receiptDateStr)){
                    try {
                        receiptDate = LocalDate.parse(receiptDateStr, formatter);
                    } catch (DateTimeParseException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid date format.");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Invalid date format.");
                }
                //create new shipment Shipment shipment = new Shipment();
                //add to warehouse listOfShipments - get warehouse object from whRepo then add shipment to list

            }
        });
        //get choice from shipMethodCombo and change into an enum ShipmentMethod
        shipMethodCombo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                //used to capture which choice is selected in the combo box

            }
        });
    }

    public List<Shipment.ShipmentMethod> getShipmentMethods() {
        return new ArrayList<Shipment.ShipmentMethod>(Arrays.asList(Shipment.ShipmentMethod.values()));
    }

    private boolean isValidDate(String dateStr) {
        boolean isValid = false;
        LocalDate date;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        try {
            date = LocalDate.parse(dateStr, formatter);
            String result = date.format(formatter);
            isValid = result.equals(dateStr) ? true : false;
        } catch (DateTimeParseException e) {
            isValid = false;
        }

        return isValid;
    }

}
