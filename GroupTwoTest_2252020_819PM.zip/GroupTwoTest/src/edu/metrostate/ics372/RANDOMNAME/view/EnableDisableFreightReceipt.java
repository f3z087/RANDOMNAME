package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.WarehouseRepository;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Controller class for the EnableDisableFreightReceiptForm.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class EnableDisableFreightReceipt extends JPanel {

    private JTextField warehouseIDText;
    private JButton enableButton;
    private JButton disableButton;
    private JPanel enDisFreightRecForm;

    /**
     * Getter for the JPanel on the EnableDisableFreightReceipt form
     *
     * @return JPanel
     */
    public JPanel getEnDisFreightRecForm() {
        return enDisFreightRecForm;
    }

    /**
     * No argument constructor, contains the button listeners and events
     */
    public EnableDisableFreightReceipt() {
        JFrame frame = new JFrame("EnableDisableFreightReceipt");
        frame.setContentPane(enDisFreightRecForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        enableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when the button is pressed get the text from the warehouse id field
                String warehouseID = warehouseIDText.getText();
                //get the warehouse object from the warehouse repository whRepo
                if (WarehouseRepository.getInstance().warehouseExists(warehouseID)) {
                    //perform the enableFreightReceipt method on the warehouse object
                    WarehouseRepository.getInstance().getWarehouse(warehouseID).enableFreightReceipt();
                    //display note it has been enabled
                    JOptionPane.showMessageDialog(null, "Freight receipt enabled.");
                } else {
                    //display message warehouse does not exist
                    JOptionPane.showMessageDialog(null, "Warehouse does not exist.");
                }

            }
        });
        disableButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when the button is pressed get the text from the warehouse id field
                String warehouseID = warehouseIDText.getText();
                //get the warehouse object from the warehouse repository whRepo
                if (WarehouseRepository.getInstance().warehouseExists(warehouseID)) {
                    //perform the enableFreightReceipt method on the warehouse object
                    WarehouseRepository.getInstance().getWarehouse(warehouseID).disableFreightReceipt();
                    //display note it has been disabled
                    JOptionPane.showMessageDialog(null, "Freight receipt disabled.");
                } else {
                    //display message warehouse does not exist
                    JOptionPane.showMessageDialog(null, "Warehouse does not exist.");
                }

            }
        });
    }

}
