package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.WarehouseRepository;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Controller class for the AddWarehouse form.
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class AddWarehouse extends JPanel {

    private JTextField warehouseIDText;
    private JTextField warehouseNameText;
    private JButton addWarehouseButton;
    private JPanel addWarehouseForm;

    /**
     * No argument constructor, contains button listeners and actions
     */
    public AddWarehouse() {
        JFrame frame = new JFrame("AddWarehouse");
        frame.setContentPane(addWarehouseForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        addWarehouseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get the text from the warehouseIDText field
                String warehouseID = warehouseIDText.getText();
                //get the text from the warehouseNameText field
                String name = warehouseNameText.getText();
                //create new warehouse and add it to the repository
                if(!warehouseID.isEmpty() && !name.isEmpty()){
                    WarehouseRepository.getInstance().addWarehouse(warehouseID, name);
                    //display message it was sucessfully added
                    //check that the warehouse actually exists
                    if(WarehouseRepository.getInstance().warehouseExists(warehouseID)){
                        JOptionPane.showMessageDialog(null, "Warehouse has been added.");
                    }
                }


            }
        });
    }

}
