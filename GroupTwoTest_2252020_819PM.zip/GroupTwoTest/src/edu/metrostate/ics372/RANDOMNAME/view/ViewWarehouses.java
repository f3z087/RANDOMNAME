package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.Warehouse;
import edu.metrostate.ics372.RANDOMNAME.model.WarehouseRepository;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;
import java.util.Map;

/**
 * Class that controls the View Warehouses form functionality
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class ViewWarehouses extends JPanel {
    private JPanel viewWarehousesForm;
    private JButton viewWarehouses;
    private JTextArea warehousesTextArea;
    private JScrollPane scrollPane;

    /**
     * No argument constructor with action listeners for buttons
     */
    public ViewWarehouses() {
        JFrame frame = new JFrame("ViewWarehouses");
        frame.setContentPane(viewWarehousesForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        viewWarehouses.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //populate the text area with the warehouse repository map or json printout
                Map<String, Warehouse> warehouseMap =  WarehouseRepository.getInstance().getWhRepo();

                for (String key: warehouseMap.keySet()) {
                    warehousesTextArea.append(warehouseMap.get(key).toString());
                    warehousesTextArea.append("\n");
                }

            }
        });
    }

}
