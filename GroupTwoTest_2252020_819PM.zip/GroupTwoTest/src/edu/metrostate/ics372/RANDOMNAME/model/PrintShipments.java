package edu.metrostate.ics372.RANDOMNAME.model;

import org.json.simple.JSONArray;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Prints the list of shipments for a warehouse.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class PrintShipments {
    private List listOfShipments;

    /**
     * Default no argument constructor, initializes the list of shipments to be made into an JSON file
     */
    public PrintShipments() {
        listOfShipments = new ArrayList<>();
    }

    /**
     * NEEDS TO BE REWRITTEN TO WORK AS A CLASS - NEED TO FIGURE OUT WHERE TO PUT THE PRINTED FILE
     * Prints the listOfShipments to a json file.
     */
    public void printReceivedShipments(String filePath) {

        JSONArray warehouseContents = new JSONArray();
        // add shipments to the list
        warehouseContents.addAll(this.listOfShipments);

        // write json file
        try (FileWriter file = new FileWriter(filePath)) {
            file.write(warehouseContents.toJSONString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
