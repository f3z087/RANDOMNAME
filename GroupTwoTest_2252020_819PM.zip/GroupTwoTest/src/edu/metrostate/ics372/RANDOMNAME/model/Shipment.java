package edu.metrostate.ics372.RANDOMNAME.model;

import java.time.LocalDate;
import java.util.Date;

/**
 * Shipment class represents one shipment.
 *
 * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
 */
public class Shipment {

    private String warehouseID;
    private ShipmentMethod shipMethod;
    private String shipmentID;
    private Long weight;
    private LocalDate receiptDate;

    /**
     * Shipment methods that can be used to send a shipment to a warehouse.
     *
     * @author RANDOMNAME Group (https://github.com/f3z087/RANDOMNAME)
     */
    public enum ShipmentMethod {
        air, truck, ship, rail;
    }

    public Shipment(String warehouseID, String shipMethod, String shipmentID, Long weight, LocalDate receiptDate) {

        this.warehouseID = warehouseID;
        this.shipMethod = ShipmentMethod.valueOf(shipMethod);
        this.shipmentID = shipmentID;
        this.weight = weight;
        this.receiptDate = receiptDate;

    }

    /**
     * Gets the receiving warehouseID of the shipment
     *
     * @return warehouseID
     */
    public String getWarehouseID() {
        return warehouseID;
    }

    /**
     * Sets the receiving warehouseID for the shipment
     *
     * @param warehouseID
     */
    public void setWarehouseID(String warehouseID) {
        this.warehouseID = warehouseID;
    }

    /**
     * Returns a String representation of the shipment method for a shipment.
     *
     * @return shipMethod
     */
    public String getShipMethod() {
        return shipMethod.toString();
    }

    /**
     * Takes a string value and converts to a ShipmentMethod to set the shipment method of a shipment.
     *
     * @param shipMethod
     */
    public void setShipMethod(String shipMethod) {
        this.shipMethod = ShipmentMethod.valueOf(shipMethod);
    }

    /**
     * Gets the shipmentID of the shipment object.
     *
     * @return shipmentID
     */
    public String getShipmentID() {
        return shipmentID;
    }

    /**
     * Sets the shipment method of the shipment.
     *
     * @param shipmentID
     */
    public void setShipmentID(String shipmentID) {
        this.shipmentID = shipmentID;
    }

    /**
     * Gets the weight of the shipment.
     *
     * @return weight
     */
    public Long getWeight() {
        return weight;
    }

    /**
     * Sets the weight of the shipment.
     *
     * @param weight
     */
    public void setWeight(Long weight) {
        this.weight = weight;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    @Override
    public String toString() {
        return "Shipment{" +
                "warehouseID='" + warehouseID + '\'' +
                ", shipMethod=" + shipMethod +
                ", shipmentID='" + shipmentID + '\'' +
                ", weight=" + weight +
                ", receiptDate=" + receiptDate +
                '}';
    }
}
