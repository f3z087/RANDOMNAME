package edu.metrostate.ics372.RANDOMNAME.view;

import edu.metrostate.ics372.RANDOMNAME.model.Shipment;
import edu.metrostate.ics372.RANDOMNAME.model.Warehouse;
import edu.metrostate.ics372.RANDOMNAME.model.WarehouseRepository;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Controller class for the AddShipmentFromFile class.
 *
 * @author RANDOMNAME Group Project (https://github.com/f3z087/RANDOMNAME)
 */
public class AddShipmentManually extends JPanel {
    private JTextField warehouseIDText;
    private JComboBox shipMethodCombo;
    private JTextField shipIDText;
    private JTextField weightText;
    private JButton addShipmentButton;
    private JPanel addShipManForm;
    private JTextField receiptDateText;

    /**
     * No argument constructor, initializes the button listeners and defines the actions.
     */
    public AddShipmentManually() {
        JFrame frame = new JFrame("AddShipmentManually");
        frame.setContentPane(addShipManForm);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        //populate combo box with shipment methods
        for (Shipment.ShipmentMethod shipmentMethod : getShipmentMethods()) {
            shipMethodCombo.addItem(shipmentMethod.name());
        }

        addShipmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //get warehouseIDText field
                String warehouseID = warehouseIDText.getText();

                //get shipMethodCombo and change into an enum
                String shipMethod = (String) shipMethodCombo.getItemAt(shipMethodCombo.getSelectedIndex());

                //get shipIDText
                String shipmentID = shipIDText.getText();

                //get weightText and change into a Long value
                String weightStr = weightText.getText();
                Double weight = Double.parseDouble(weightStr);

                //get receipt date and change into Date format
                Date receiptDate = null;
                String formatter = "yyyy-MM-dd";
                String receiptDateStr = receiptDateText.getText();
                //if it is a valid date then set the receipt date if not display message
                if (isValidDate(receiptDateStr)) {
                    try {
                        receiptDate = new SimpleDateFormat(formatter).parse(receiptDateStr);
                    } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid date format.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid date format.");
                }

                //create new shipment Shipment shipment = new Shipment();
                if(receiptDate != null && weight != null){
                    Shipment shipment = new Shipment(warehouseID, shipMethod, shipmentID, weight, receiptDate);
                    //add to warehouse listOfShipments - get warehouse object from whRepo then add shipment to list
                    Warehouse warehouse = WarehouseRepository.getInstance().getWarehouse(warehouseID);
                    warehouse.addIncomingShipment(shipment);
                    JOptionPane.showMessageDialog(null, "Shipment added.");
                }
            }
        });
        //get choice from shipMethodCombo and change into an enum ShipmentMethod
        shipMethodCombo.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                //used to capture which choice is selected in the combo box

            }
        });
    }

    public List<Shipment.ShipmentMethod> getShipmentMethods() {
        return new ArrayList<Shipment.ShipmentMethod>(Arrays.asList(Shipment.ShipmentMethod.values()));
    }

    private boolean isValidDate(String dateStr) {
        boolean isValid = false;
        Date date;
        String formatter = "yyyy-MM-dd";
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date = new SimpleDateFormat(formatter).parse(dateStr);
            String result = dateFormat.format(date);
            isValid = result.equals(dateStr) ? true : false;
        } catch (ParseException e) {
            isValid = false;
        }

        return isValid;
    }

}
