package edu.metrostate.ics372.snowywhitemn;

/**
 * Reads in shipments from JSON file.
 * 
 * @author vwhite
 *
 */
public class readInShipments {

}
