package edu.metrostate.ics372.snowywhitemn;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * Program for a transportation company that sends freight. Admins will need to
 * be able to record shipments that arrive at the various warehouses.
 * 
 * USING GSON (does not work)
 * 
 * @author Victoria White
 *
 */
public class SendFreightDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// https://mkyong.com/java/how-to-parse-json-with-gson/
		// https://www.tutorialspoint.com/gson/gson_first_application.htm
		// https://howtodoinjava.com/gson/gson-parse-json-array/

		String filePath = SendFreightDriver.class.getResource("example.json").getPath();

		try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
			Gson gson = new Gson();

			Type shipmentListType = new TypeToken<List<Shipment>>() {
			}.getType();
			List<Shipment> shipmentArray = gson.fromJson(reader, shipmentListType);

			for (Shipment shipment : shipmentArray) {
				System.out.println(shipment);

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
