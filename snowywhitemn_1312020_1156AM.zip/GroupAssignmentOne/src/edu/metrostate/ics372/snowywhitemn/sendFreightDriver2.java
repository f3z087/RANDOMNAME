package edu.metrostate.ics372.snowywhitemn;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import edu.metrostate.ics372.snowywhitemn.Shipment.ShipmentMethod;

/**
 * Using j simple
 * 
 * @author vwhite
 *
 */
public class sendFreightDriver2 {

	public static void main(String[] args) {

		List<Shipment> shipments = new ArrayList<>();
		// will be asking for local file path from user
		String filePath = SendFreightDriver.class.getResource("example.json").getPath();

		// https://howtodoinjava.com/library/json-simple-read-write-json-examples/
		// https://java2blog.com/jsonsimple-example-read-and-write-json/
		// https://www.javaguides.net/2019/07/jsonsimple-tutorial-read-and-write-json-in-java.html

		// JSON parser object to parse read file
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader(filePath)) {

			try {
				// read JSON file
				Object obj = jsonParser.parse(reader);

				// convert object to JSONObject
				JSONObject jsonObject = (JSONObject) obj;

				JSONArray arrayOfShipments = (JSONArray) jsonObject.get("warehouse_contents");

				// check size if more than 0, there is objects inside the array
				System.out.println(arrayOfShipments.size());

				// create shipment objects
				Iterator i = arrayOfShipments.iterator();
				while (i.hasNext()) {

					JSONObject innerObject = (JSONObject) i.next();
					int warehouseId = Integer.parseInt((String) innerObject.get("warehouse_id"));
					ShipmentMethod shipmentMethod = ShipmentMethod.valueOf((String) innerObject.get("shipment_method"));
					String shipmentId = (String) innerObject.get("shipment_id");
					var tempWeight = innerObject.get("weight");
					String receiptDate = (String) innerObject.get("receiptDate");

					Double weight = 0.0;
					if (tempWeight instanceof Double) {
						weight = (Double) tempWeight;
					} else if (tempWeight instanceof Long) {
						weight = tempWeight.doubleValue();
					}

					Shipment shipment = new Shipment(warehouseId, shipmentMethod, shipmentId, weight);
					if (shipment.getWeight() != 0.0) {
						shipments.add(shipment);
					}

					System.out.println(shipment);

				}

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
